
print('123')